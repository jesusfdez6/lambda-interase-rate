module.exports = {
    NAME_LAMBDA : "INTERASE-RATE"
}